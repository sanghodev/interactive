const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d', { alpha: false });
const indicator = document.getElementById('indicator');
const valorOverlay = document.getElementById('valor');
const logicOverlay = document.getElementById('logic');

let currentProgress = 0.5;
let targetProgress = 0.5;

function lerp(a, b, n) {
    return (1 - n) * a + n * b;
}

const imgA = new Image();
const imgB = new Image();
imgA.src = 'assets/corporate.jpg';
imgB.src = 'assets/athlete.jpg';

function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}

window.addEventListener('resize', resize);
resize();

function getDrawMeta(img, w, h) {
    const imgRatio = img.width / img.height;
    const canvasRatio = w / h;
    let drawW, drawH, offsetX, offsetY;
    if (imgRatio > canvasRatio) {
        drawW = h * imgRatio;
        drawH = h;
        offsetX = (w - drawW) / 2;
        offsetY = 0;
    } else {
        drawW = w;
        drawH = w / imgRatio;
        offsetX = 0;
        offsetY = (h - drawH) / 2;
    }
    return { drawW, drawH, offsetX, offsetY };
}

function render() {
    // Smooth progress update (spring-like lerp)
    currentProgress = lerp(currentProgress, targetProgress, 0.08);

    const width = canvas.width;
    const height = canvas.height;
    const time = Date.now() * 0.001;

    // Background fill
    ctx.fillStyle = '#050505';
    ctx.fillRect(0, 0, width, height);

    // Update UI elements
    indicator.style.left = (currentProgress * 100).toFixed(2) + '%';
    
    // Opacities based on progress (parity with Exp 30)
    const vOpacity = Math.max(0, Math.min(1, (0.6 - currentProgress) / 0.3));
    const lOpacity = Math.max(0, Math.min(1, (currentProgress - 0.4) / 0.3));
    valorOverlay.style.opacity = vOpacity;
    logicOverlay.style.opacity = lOpacity;

    // 1. Draw Base Layer (Athlete - Image B)
    if (imgB.complete && imgB.naturalWidth > 0) {
        const meta = getDrawMeta(imgB, width, height);
        ctx.drawImage(imgB, meta.offsetX, meta.offsetY, meta.drawW, meta.drawH);
    }

    // 2. Draw Mosaic Layer (Corporate - Image A)
    if (imgA.complete && imgA.naturalWidth > 0) {
        const metaA = getDrawMeta(imgA, width, height);
        const pixelSize = 16;
        const cols = Math.ceil(width / pixelSize);
        const rows = Math.ceil(height / pixelSize);
        
        ctx.globalAlpha = 1.0;

        for (let i = 0; i < cols; i++) {
            for (let j = 0; j < rows; j++) {
                const x = i * pixelSize;
                const y = j * pixelSize;
                
                const relX = i / cols;
                const relY = j / rows;
                
                let noise = Math.sin(relX * 10 + time * 0.5) * Math.cos(relY * 8 + time * 0.3) * 0.12;
                noise += Math.sin(relX * 20 - time * 0.7) * 0.04;
                
                const threshold = relX + noise;
                
                if (currentProgress > threshold) {
                    const diff = currentProgress - threshold;
                    const scale = Math.min(1.0, diff * 12);
                    
                    if (scale > 0.01) {
                        const sSize = pixelSize * scale;
                        const offset = (pixelSize - sSize) / 2;

                        const relativeXInDraw = x - metaA.offsetX;
                        const relativeYInDraw = y - metaA.offsetY;
                        
                        if (relativeXInDraw >= 0 && relativeXInDraw < metaA.drawW &&
                            relativeYInDraw >= 0 && relativeYInDraw < metaA.drawH) {
                            
                            const sampleX = (relativeXInDraw / metaA.drawW) * imgA.width;
                            const sampleY = (relativeYInDraw / metaA.drawH) * imgA.height;
                            
                            ctx.drawImage(
                                imgA, 
                                sampleX, sampleY, 1, 1, 
                                x + offset, y + offset, sSize, sSize
                            );
                        }
                    }
                }
            }
        }
    }

    requestAnimationFrame(render);
}

render();

function handleMove(clientX) {
    targetProgress = Math.max(0, Math.min(1, clientX / window.innerWidth));
}

window.addEventListener('mousemove', (e) => handleMove(e.clientX));
window.addEventListener('touchmove', (e) => {
    if (e.touches.length > 0) handleMove(e.touches[0].clientX);
}, { passive: true });
