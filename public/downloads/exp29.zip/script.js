const container = document.getElementById('container');
const corporateLayer = document.getElementById('corporateLayer');
const athleteContent = document.querySelector('.athlete .content');
const corporateContent = document.querySelector('.corporate .content');

let currentX = 0.5;
let targetX = 0.5;

function lerp(a, b, n) {
    return (1 - n) * a + n * b;
}

function update() {
    // Smooth lerp for the reveal line
    currentX = lerp(currentX, targetX, 0.1);
    
    // Update CSS variable for clip-path and indicator position
    const percentage = (currentX * 100).toFixed(2) + '%';
    document.documentElement.style.setProperty('--clip', percentage);
    
    // Update opacities based on progress (parity with Exp 29)
    // athleteOpacity: 0.4 -> 0.6 maps to 1 -> 0
    // corporateOpacity: 0.4 -> 0.6 maps to 0 -> 1
    
    const athleteOpacity = Math.max(0, Math.min(1, (0.6 - currentX) / 0.2));
    const corporateOpacity = Math.max(0, Math.min(1, (currentX - 0.4) / 0.2));
    
    athleteContent.style.opacity = athleteOpacity;
    corporateContent.style.opacity = corporateOpacity;
    
    requestAnimationFrame(update);
}

function handleMove(clientX) {
    const rect = container.getBoundingClientRect();
    const x = (clientX - rect.left) / rect.width;
    targetX = Math.max(0, Math.min(1, x));
}

window.addEventListener('mousemove', (e) => handleMove(e.clientX));
window.addEventListener('touchmove', (e) => {
    if (e.touches.length > 0) {
        handleMove(e.touches[0].clientX);
    }
}, { passive: false });

update();
